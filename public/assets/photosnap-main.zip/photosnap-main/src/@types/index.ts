export interface ICardProps {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    data: any;
}

export interface IBackground {
    background: string;
}
